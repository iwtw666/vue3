<template>
  <div class="min-w-3xl">
    <input type="file" multiple accept=".stl" @change="handleUploadChange" />
    <div id="canvas-container"></div>
  </div>
</template>

<script lang="ts">
import { ThreeJs, THREE } from '@/components/ThreeJs/index'

export default defineComponent({
  setup() {
    let threeJs: ThreeJs | null = null
    let scene: THREE.Scene | null = null
    let camera: THREE.Camera | null = null
    const { models } = window.g
    const initCanvas = (): void => {
      const dom = document.getElementById('canvas-container') as HTMLCanvasElement
      threeJs = new ThreeJs(dom)
      scene = threeJs.scene
      camera = threeJs.camera
    }
    const showModels = (): void => {
      if (scene) {
        threeJs?.showModels(models).then(() => {
          console.log(models)
        })
      }
    }
    onMounted(() => {
      initCanvas()
    })
    const handleUploadChange = (event: any): void => {
      const { files } = event.target
      for (let i = 0; i < files.length; i += 1) {
        models.push(files[i])
      }
      showModels()
    }

    const foo = () => {
      console.log('test')
    }
    return {
      handleUploadChange,
      foo,
    }
  },
})
</script>

<style lang="scss" scoped>
a {
  @apply text-sky-400 hover:(text-sky-600) transition-all ease-out duration-100;
}
#canvas-container {
  @apply w-256 h-192;
}
</style>

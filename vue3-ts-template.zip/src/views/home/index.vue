<template>
  <div class="w-100% mt-5 flex justify-center">
    <test3d-vue />
  </div>
</template>

<script setup lang="ts">
import test3dVue from '../pages/test-3d.vue'

const { t } = useI18n()
const notify = () => {
  ElMessage.info({ message: 'welcome', duration: 1000 })
  ElNotification({
    title: 'Issue',
    message: 'If you encounter problems in using the template, please raise them in the issue',
    duration: 2000,
  })
}
notify()
</script>

<style lang="scss" scoped>
a {
  @apply text-sky-400 hover:(text-sky-600) transition-all ease-out duration-100;
}
</style>

import * as THREE from 'three'
import { computeBoundsTree, disposeBoundsTree, acceleratedRaycast } from 'three-mesh-bvh'

import STLLoader from './STLLoader'
import TrackballControls from './TrackballControls'

THREE.BufferGeometry.prototype.computeBoundsTree = computeBoundsTree
THREE.BufferGeometry.prototype.disposeBoundsTree = disposeBoundsTree
THREE.Mesh.prototype.raycast = acceleratedRaycast
THREE.Raycaster.prototype.firstHitOnly = true

function handleMatrix(matrix: any): THREE.Matrix4 {
  const result = new THREE.Matrix4()
  if (!matrix) {
    return result
  }
  if (matrix instanceof THREE.Matrix4) {
    return matrix
  }
  if (matrix instanceof Array) {
    const elesM: any =
      matrix[0] instanceof Array
        ? matrix
            .reduce((pre, cur) => {
              return pre.concat(cur)
            }, [])
            .map((n: any) => Number(n))
        : matrix.map((n) => Number(n)).reverse()
    if (elesM.filter((num: number) => Number.isNaN(num)).length > 0) {
      return result
    }
    result.set.apply(null, elesM) // apply 来解决...问题
  }
  return result
}

class ThreeJs {
  canvas: HTMLCanvasElement | null = null

  renderer: THREE.WebGLRenderer | null = null

  scene: THREE.Scene | null = null

  camera: THREE.PerspectiveCamera | null = null

  control: TrackballControls | null = null

  modelMaterial: THREE.Material | null = null

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas
    this.init()
  }

  init(): void {
    if (this.canvas) {
      this.createScene()
      const matcap = new THREE.TextureLoader().load('/static/texture.jpg')
      this.modelMaterial = new THREE.MeshMatcapMaterial({
        matcap,
        side: THREE.DoubleSide,
        color: 0xffffff,
        transparent: true,
      })
    } else {
      ElMessage.warning('no canvas dom')
    }
  }

  createScene(): void {
    const canvasWidth: number = this.canvas?.clientWidth || 1024
    const canvasHeight: number = this.canvas?.clientHeight || 768

    this.scene = new THREE.Scene()
    this.camera = new THREE.PerspectiveCamera(35, canvasWidth / canvasHeight, 0.1, 1500)
    this.camera.position.set(0, -450, 220)
    this.camera.lookAt(new THREE.Vector3(0, 0, 0))
    this.scene.add(this.camera)

    this.scene.add(new THREE.AmbientLight(0x555555))

    const light: THREE.Light = new THREE.SpotLight(0xfafafa)
    light.position.set(0, 1000, 1000)
    const light1: THREE.Light = light.clone()
    light1.position.set(0, 1000, -1000)
    light.castShadow = true
    light1.castShadow = true
    this.scene.add(light)
    this.scene.add(light1)

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true })
    this.renderer.setPixelRatio(window.devicePixelRatio)
    this.renderer.setSize(canvasWidth, canvasHeight)
    this.renderer.shadowMap.enabled = true
    this.renderer.setClearColor(0xf6f7f8, 1.0)
    this.renderer.localClippingEnabled = true

    this.canvas?.appendChild(this.renderer.domElement)
    this.renderer.render(this.scene, this.camera)
    this.renderer.domElement.addEventListener(
      'contextmenu',
      (e) => {
        e.preventDefault()
      },
      false,
    )

    this.control = new TrackballControls(this.camera, this.renderer.domElement)
    this.control.rotateSpeed = 6
    this.control.zoomSpeed = 4.5
    this.control.panSpeed = 0.5
    this.control.minDistance = 1
    this.control.maxDistance = 1000

    window.onresize = (): void => {
      const width = this.canvas?.clientWidth
      const height = this.canvas?.clientHeight
      if (this.renderer && width && height) {
        this.renderer.domElement.width = width
        this.renderer.domElement.height = height
        if (this.camera) this.camera.aspect = width / height
        this.renderer?.setSize(width, height)
      }
    }

    const animate = (): void => {
      requestAnimationFrame(animate)
      if (this.scene && this.camera) {
        this.renderer?.render(this.scene, this.camera)
        this.control?.update()
      }
    }

    animate()
    window.dispatchEvent(new Event('resize')) // 手动触发一次resize
  }

  showModels(files: any[], matrix = null, center = true) {
    return new Promise<void>((resolve, reject) => {
      const filesArr = []
      for (let i = 0; i < files.length; i++) {
        const file = files[i]
        if (file instanceof THREE.Mesh) {
          this.scene?.add(file)
        } else if (file instanceof File || file instanceof Blob) {
          filesArr.push(file)
        }
      }
      if (filesArr.length) {
        const loader = new STLLoader()
        loader?.loadAll(filesArr).then((result) => {
          const { successList, errorList } = result
          if (errorList.length && !successList.length) {
            alert('上传的模型存在问题，请重试！')
            return window.location.reload()
          }
          if (errorList.length) {
            alert('部分模型有问题，已被删除！')
          }
          if (successList.length) {
            files.length = 0
            for (let m = 0; m < successList.length; m++) {
              const geometry = successList[m]
              if (matrix) {
                const straightenM = handleMatrix(matrix)
                geometry.applyMatrix4(straightenM)
              }
              if (center) {
                geometry.computeBoundingSphere()
                ;(geometry as any).orginCenter = geometry.boundingSphere?.center
                geometry.center()
              }
              const mesh: any = new THREE.Mesh(geometry, this.modelMaterial?.clone())
              mesh.name = geometry.name
              // mesh.partId = (geometry as any).partidd // TODO: partid 是否存在，以及存在位置
              this.scene?.add(mesh)
              files.push(mesh)
            }
          }

          return resolve()
        })
      } else {
        resolve()
      }
    })
  }

  dispose(): void {
    if (this.modelMaterial) {
      if (this.modelMaterial instanceof THREE.MeshMatcapMaterial) {
        if (this.modelMaterial?.matcap?.dispose) {
          this.modelMaterial?.matcap.dispose()
        }
      }
      this.modelMaterial.dispose()
      this.modelMaterial = null
    }
    if (this.control) {
      if (this.control.dispose) this.control.dispose()
      this.control = null
    }
    if (this.scene) {
      this.scene.children.forEach((item: any) => {
        if (item.dispose) item.dispose()
        if (item.material) item.material.dispose()
        if (item.geometry) item.geometry.dispose()
        if (item.children && item.children.length) {
          item.children.forEach((child: any) => {
            if (child.dispose) child.dispose()
            if (child.material) child.material.dispose()
            if (child.geometry) child.geometry.dispose()
          })
          item.children.length = 0
        }
      })
      this.scene.children.length = 0
      this.scene = null
    }
    if (this.camera) {
      this.camera = null
    }
    if (this.renderer) {
      if (this.renderer.dispose) this.renderer.dispose()
      this.renderer.forceContextLoss()
      this.renderer = null
    }
  }
}

export { ThreeJs, THREE }

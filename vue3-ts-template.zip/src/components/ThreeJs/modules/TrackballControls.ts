/* eslint-disable */

import * as THREE from 'three'

const CHANGEEVENT: any = { type: 'change' }
const STARTEVENT: any = { type: 'start' }
const ENDEVENT: any = { type: 'end' }

class TrackballControls extends THREE.EventDispatcher {
  object: THREE.PerspectiveCamera | null = null

  domElement: HTMLElement | HTMLCanvasElement | undefined

  // 表示这个类是否起作用；如果为false鼠标交互没有效果
  enabled = true

  // 设置屏幕的位置和偏移
  screen: any = { left: 0, top: 0, width: 0, height: 0 }

  rotateSpeed = 1.0 // 移动鼠标时场景旋转的速度

  zoomSpeed = 1.2 // 鼠标滚轮放大缩小的速度

  panSpeed = 0.3 // 上下左右移动的速度

  // 控制旋转、作坊、平移
  noRotate = false

  noZoom = false

  noPan = false

  staticMoving = false

  dynamicDampingFactor = 0.2 // 阻尼系数；旋转时候的阻力

  xPanFactor = 3

  // 表示相机距离物体的最小距离和最大距离
  minDistance = 0

  maxDistance = Infinity

  // 定义键盘A S D的ASCII码
  keys: string[] = ['KeyA' /* A */, 'KeyS' /* S */, 'KeyD']

  mouseButtons: any = { LEFT: 0, MIDDLE: 1, RIGHT: 2 } // 左中右鼠标按钮’event.button‘代码，mac系统（os 13以前）上可能不同

  // internals这些私有变量用来追踪相机状态

  target: THREE.Vector3 = new THREE.Vector3() // 目标点

  // for reset
  // 保存相机的最初始状态
  target0: THREE.Vector3

  position0: THREE.Vector3

  up0: THREE.Vector3

  zoom0: number

  handleResize: () => void

  rotateCamera: () => void

  zoomCamera: () => void

  panCamera: () => void

  checkDistances: () => void

  update: () => void

  reset: () => void

  dispose: () => void

  transparentPlane: (plane: any) => void

  setXDam: (val: any) => void

  constructor(object: THREE.PerspectiveCamera, domElement: HTMLElement | HTMLCanvasElement | undefined) {
    super()

    if (domElement === undefined)
      console.warn('THREE.TrackballControls: The second parameter "domElement" is now mandatory.')

    const scope = this
    // 这个类有六种状态
    const STATE = { NONE: -1, ROTATE: 0, ZOOM: 1, PAN: 2, TOUCH_ROTATE: 3, TOUCH_ZOOM_PAN: 4 }

    this.object = object // object指向相机
    this.domElement = domElement
    if (this.domElement) this.domElement.style.touchAction = 'none' // disable touch scroll

    // API
    //

    const EPS = 0.000001

    const lastPosition = new THREE.Vector3() // 相机上次的位置
    let lastZoom = 1

    let _state = STATE.NONE // 相机当前状态
    let _keyState = STATE.NONE

    let _touchZoomDistanceStart = 0
    let _touchZoomDistanceEnd = 0

    let _lastAngle = 0

    const _eye = new THREE.Vector3() // 眼睛的朝向

    const _movePrev: any = new THREE.Vector2()
    const _moveCurr = new THREE.Vector2()

    const _lastAxis = new THREE.Vector3()

    const _zoomStart = new THREE.Vector2()
    const _zoomEnd = new THREE.Vector2()

    const _panStart = new THREE.Vector2()
    const _panEnd = new THREE.Vector2()

    const _pointers: any[] = []
    const _pointerPositions: any = {}

    // for reset
    // 保存相机的最初始状态
    this.target0 = this.target.clone()
    this.position0 = this.object.position.clone() // 相机的当前位置
    this.up0 = this.object.up.clone() // 相机的上方向
    this.zoom0 = this.object.zoom

    // methods

    this.handleResize = function () {
      const box = scope.domElement?.getBoundingClientRect()
      // adjustments come from similar code in the jquery offset() function
      const d = scope.domElement?.ownerDocument.documentElement
      if (box && d) {
        scope.screen.left = box.left + window.pageXOffset - d.clientLeft
        scope.screen.top = box.top + window.pageYOffset - d.clientTop
        scope.screen.width = box.width
        scope.screen.height = box.height
      }
    }

    const getMouseOnScreen = (function () {
      const vector = new THREE.Vector2()
      // 将鼠标坐标转换成0-1，左上角为0，0右下角为1，1

      return function getMouseOnScreen(pageX: number, pageY: number) {
        vector.set((pageX - scope.screen.left) / scope.screen.width, (pageY - scope.screen.top) / scope.screen.height)

        return vector
      }
    })()

    const getMouseOnCircle = (function () {
      const vector = new THREE.Vector2()

      return function getMouseOnCircle(pageX: number, pageY: number) {
        // 将鼠标位置转换为圆坐标, 由于屏幕宽高未必一致，
        // 这里以宽度一半作为半径
        vector.set(
          (pageX - scope.screen.width * 0.5 - scope.screen.left) / (scope.screen.width * 0.5),
          (scope.screen.height + 2 * (scope.screen.top - pageY)) / scope.screen.width, // screen.width intentional
        )

        return vector
      }
    })()

    this.rotateCamera = (function () {
      const axis = new THREE.Vector3()
      const quaternion = new THREE.Quaternion()
      const eyeDirection = new THREE.Vector3()
      const objectUpDirection = new THREE.Vector3()
      const objectSidewaysDirection = new THREE.Vector3()
      const moveDirection = new THREE.Vector3()

      // 旋转实际相当于将手势在相机屏幕上的移动转化为在一个以焦点为圆心的球上的转动
      // moveDiection就是我们要将相机eye向量的旋转方向
      // 3d中要将一个向量向另一个向量靠拢，最好使用四元数来做旋转
      return function rotateCamera() {
        // moveDirection表示以相机屏幕中心点为圆心，在相机屏幕上的一个向量
        moveDirection.set(_moveCurr.x - _movePrev.x, _moveCurr.y - _movePrev.y, 0)
        let angle = moveDirection.length()
        if (scope.object) {
          if (angle) {
            // 判断是否有旋转
            _eye.copy(scope.object.position).sub(scope.target)

            eyeDirection.copy(_eye).normalize() // 相机视线轴
            objectUpDirection.copy(scope.object.up).normalize() // 相机up轴
            objectSidewaysDirection.crossVectors(objectUpDirection, eyeDirection).normalize() // 相机x轴

            objectUpDirection.setLength(_moveCurr.y - _movePrev.y) // y轴移动距离
            objectSidewaysDirection.setLength(_moveCurr.x - _movePrev.x) // x轴移动距离
            // moveDiection就是我们要将相机eye向量的旋转方向
            moveDirection.copy(objectUpDirection.add(objectSidewaysDirection)) // 计算出在相机屏幕的移动向量

            axis.crossVectors(moveDirection, _eye).normalize() // 计算出四元数的旋转轴
            // 3d中要将一个向量向另一个向量靠拢，最好使用四元数来做旋转
            angle *= scope.rotateSpeed // 将相机屏幕移动距离转化为角度
            quaternion.setFromAxisAngle(axis, angle)

            // 对视线轴和相机up轴应用四元数旋转
            // 对eye和up同时旋转保持二者相对位置关系
            _eye.applyQuaternion(quaternion)
            scope.object.up.applyQuaternion(quaternion)
            // 控制点中心也旋转
            scope.target.applyQuaternion(quaternion)
            _lastAxis.copy(axis)
            _lastAngle = angle
          } else if (!scope.staticMoving && _lastAngle) {
            _lastAngle *= Math.sqrt(1.0 - scope.dynamicDampingFactor)
            _eye.copy(scope.object.position).sub(scope.target)
            quaternion.setFromAxisAngle(_lastAxis, _lastAngle)
            _eye.applyQuaternion(quaternion)
            scope.object.up.applyQuaternion(quaternion)
            // 控制点中心也旋转
            scope.target.applyQuaternion(quaternion)
          }
        }

        _movePrev.copy(_moveCurr)
      }
    })()

    // 透视相机的效果是近大远小当相机离物体越近物体显示越大
    // 所以在透视情况下做放大缩小只要改变eye向量的长度
    this.zoomCamera = function () {
      let factor

      if (_state === STATE.TOUCH_ZOOM_PAN) {
        factor = _touchZoomDistanceStart / _touchZoomDistanceEnd
        _touchZoomDistanceStart = _touchZoomDistanceEnd

        if (scope.object?.isPerspectiveCamera) {
          _eye.multiplyScalar(factor)
        } else {
          console.warn('THREE.TrackballControls: Unsupported camera type')
        }
      } else {
        // 获取放到缩小的倍数，这个倍数不能小于0；当倍数小于1时为缩小，
        // 当倍数大于1时为放大
        factor = 1.0 + (_zoomEnd.y - _zoomStart.y) * scope.zoomSpeed

        if (factor !== 1.0 && factor > 0.0) {
          if (scope.object?.isPerspectiveCamera) {
            _eye.multiplyScalar(factor)
          } else {
            console.warn('THREE.TrackballControls: Unsupported camera type')
          }
        }

        if (scope.staticMoving) {
          _zoomStart.copy(_zoomEnd)
        } else {
          // 做一个动画效果
          _zoomStart.y += (_zoomEnd.y - _zoomStart.y) * this.dynamicDampingFactor
        }
      }
    }

    this.panCamera = (() => {
      const mouseChange = new THREE.Vector2()
      const objectUp = new THREE.Vector3()
      const pan = new THREE.Vector3()

      return () => {
        // 屏幕左上点为0，0右下点为1，1
        // 这里得到鼠标移动的方向和距离 （二维向量）
        mouseChange.copy(_panEnd).sub(_panStart)

        if (mouseChange.lengthSq()) {
          // 移动的距离跟相机距离物体的距离成正比
          // 相机距离物体越远移动距离越多；
          // 但这样做的感觉并不是很好
          mouseChange.multiplyScalar(_eye.length() * scope.panSpeed)

          const rFactor = 1.0 + (_panEnd.y - _panStart.y) * scope.panSpeed // 消除近大远小
          if (scope.object?.isPerspectiveCamera) {
            _eye.multiplyScalar(rFactor)
          }
          // 得出相机的right轴方向和up轴方向的移动距离
          // 注意这时候的用的坐标都是世界坐标
          if (scope.object) {
            pan
              .copy(_eye)
              .cross(scope.object.up)
              .setLength(mouseChange.x / this.xPanFactor) // 消除近大远小：减慢x平移速度
            pan.add(objectUp.copy(scope.object.up).setLength(mouseChange.y))
            // 移动相机位置和聚焦点位置，保持eye向量不变
            // 这里保证无论怎么旋转场景，当鼠标做平移操作时，
            // 场景都是平行于屏幕上下移动的，而不是相对于他们自己的模型坐标系移动
            scope.object.position.add(pan)
            scope.target.add(pan) // 如果焦点没有移动我们相当于一直在盯着一个点看
          }

          if (scope.staticMoving) {
            // 一次性移动
            _panStart.copy(_panEnd)
          } else {
            // 多次缓慢移动
            _panStart.add(mouseChange.subVectors(_panEnd, _panStart).multiplyScalar(scope.dynamicDampingFactor))
          }
        }
      }
    })()

    // 相机的可视范围的远近由近景面和远景面决定；
    // 如果相机无限缩小小于近景面或物体离着相机的距离大于远景面
    // 那么相机将不会看到任何东西；所以有时候我们要控制相机的跟物体的距离
    this.checkDistances = function () {
      if (!scope.noZoom || !scope.noPan) {
        // 根据鼠标距离物体的最大最小距离来调整相机位置
        if (_eye.lengthSq() > scope.maxDistance * scope.maxDistance) {
          scope.object?.position.addVectors(scope.target, _eye.setLength(scope.maxDistance))
          _zoomStart.copy(_zoomEnd)
        }

        if (_eye.lengthSq() < scope.minDistance * scope.minDistance) {
          scope.object?.position.addVectors(scope.target, _eye.setLength(scope.minDistance))
          _zoomStart.copy(_zoomEnd)
        }
      }
    }

    /**
     * 这个函数会不断的更新相机位置和方向来反映相机的变化，
     * 屏幕的内容也会跟着变化
     * @return {[type]} [description]
     */
    this.update = function () {
      if (scope.object) {
        // 计算目标点到相机点的距离
        _eye.subVectors(scope.object.position, scope.target)
        // 更新旋转部分
        if (!scope.noRotate) {
          scope.rotateCamera()
        }
        // 更新缩放部分
        if (!scope.noZoom) {
          scope.zoomCamera()
        }
        // 更新上下左右移动相机部分
        if (!scope.noPan) {
          scope.panCamera()
        }
        // 更新相机当前的位置
        scope.object.position.addVectors(scope.target, _eye)

        if (scope.object.isPerspectiveCamera) {
          // 检查相机的位置是否在minDistance和maxDistance之间
          scope.checkDistances()
          // 从相机点看到目标点得到相机的模型矩阵
          scope.object.lookAt(scope.target)
          // 当相机位置变化后，发送一个相机状态改变的事件
          if (lastPosition.distanceToSquared(scope.object.position) > EPS) {
            scope.dispatchEvent(CHANGEEVENT)
            // 保存相机当前位置
            lastPosition.copy(scope.object.position)
          }
        } else {
          console.warn('THREE.TrackballControls: Unsupported camera type')
        }
      }
    }

    this.reset = function () {
      _state = STATE.NONE
      _keyState = STATE.NONE
      if (scope.object) {
        scope.target.copy(scope.target0)
        scope.object.position.copy(scope.position0)
        scope.object.up.copy(scope.up0)
        scope.object.zoom = scope.zoom0

        scope.object.updateProjectionMatrix()

        _eye.subVectors(scope.object.position, scope.target)

        scope.object.lookAt(scope.target)

        scope.dispatchEvent(CHANGEEVENT)

        lastPosition.copy(scope.object.position)
        lastZoom = scope.object.zoom
      }
    }

    // listeners
    function getSecondPointerPosition(event: any) {
      const pointer = event.pointerId === _pointers[0].pointerId ? _pointers[1] : _pointers[0]

      return _pointerPositions[pointer.pointerId]
    }
    function trackPointer(event: any) {
      let position = _pointerPositions[event.pointerId]

      if (position === undefined) {
        position = new THREE.Vector2()
        _pointerPositions[event.pointerId] = position
      }

      position.set(event.pageX, event.pageY)
    }
    function onTouchMove(event: any) {
      trackPointer(event)

      switch (_pointers.length) {
        case 1:
          _movePrev.copy(_moveCurr)
          _moveCurr.copy(getMouseOnCircle(event.pageX, event.pageY))
          break

        default: // 2 or more
          const position = getSecondPointerPosition(event)

          const dx = event.pageX - position.x
          const dy = event.pageY - position.y
          _touchZoomDistanceEnd = Math.sqrt(dx * dx + dy * dy)

          const x = (event.pageX + position.x) / 2
          const y = (event.pageY + position.y) / 2
          _panEnd.copy(getMouseOnScreen(x, y))
          break
      }
    }
    function onMouseMove(event: any) {
      const state = _keyState !== STATE.NONE ? _keyState : _state

      if (state === STATE.ROTATE && !scope.noRotate) {
        _movePrev.copy(_moveCurr)
        _moveCurr.copy(getMouseOnCircle(event.pageX, event.pageY))
      } else if (state === STATE.ZOOM && !scope.noZoom) {
        _zoomEnd.copy(getMouseOnScreen(event.pageX, event.pageY))
      } else if (state === STATE.PAN && !scope.noPan) {
        _panEnd.copy(getMouseOnScreen(event.pageX, event.pageY))
      }
    }
    function onPointerMove(event: any) {
      if (scope.enabled === false) return

      if (event.pointerType === 'touch') {
        onTouchMove(event)
      } else {
        onMouseMove(event)
      }
    }
    function onTouchEnd(event: any) {
      switch (_pointers.length) {
        case 0:
          _state = STATE.NONE
          break

        case 1:
          _state = STATE.TOUCH_ROTATE
          _moveCurr.copy(getMouseOnCircle(event.pageX, event.pageY))
          _movePrev.copy(_moveCurr)
          break

        case 2:
          _state = STATE.TOUCH_ZOOM_PAN
          _moveCurr.copy(getMouseOnCircle(event.pageX - _movePrev.pageX, event.pageY - _movePrev.pageY))
          _movePrev.copy(_moveCurr)
          break
      }

      scope.dispatchEvent(ENDEVENT)
    }
    function onMouseUp() {
      _state = STATE.NONE

      scope.dispatchEvent(ENDEVENT)
    }
    function removePointer(event: any) {
      delete _pointerPositions[event.pointerId]

      for (let i = 0; i < _pointers.length; i += 1) {
        if (_pointers[i].pointerId === event.pointerId) {
          _pointers.splice(i, 1)
          return
        }
      }
    }
    function onPointerUp(event: any) {
      if (scope.enabled === false) return

      if (event.pointerType === 'touch') {
        onTouchEnd(event)
      } else {
        onMouseUp()
      }

      //

      removePointer(event)

      if (_pointers.length === 0) {
        scope.domElement?.releasePointerCapture(event.pointerId)

        scope.domElement?.removeEventListener('pointermove', onPointerMove)
        scope.domElement?.removeEventListener('pointerup', onPointerUp)
      }
    }
    function addPointer(event: any) {
      _pointers.push(event)
    }
    function onTouchStart(event: any) {
      trackPointer(event)

      switch (_pointers.length) {
        case 1:
          _state = STATE.TOUCH_ROTATE
          _moveCurr.copy(getMouseOnCircle(_pointers[0].pageX, _pointers[0].pageY))
          _movePrev.copy(_moveCurr)
          break

        default: // 2 or more
          _state = STATE.TOUCH_ZOOM_PAN
          const dx = _pointers[0].pageX - _pointers[1].pageX
          const dy = _pointers[0].pageY - _pointers[1].pageY
          _touchZoomDistanceEnd = _touchZoomDistanceStart = Math.sqrt(dx * dx + dy * dy)

          const x = (_pointers[0].pageX + _pointers[1].pageX) / 2
          const y = (_pointers[0].pageY + _pointers[1].pageY) / 2
          _panStart.copy(getMouseOnScreen(x, y))
          _panEnd.copy(_panStart)
          break
      }

      scope.dispatchEvent(STARTEVENT)
    }
    function onMouseDown(event: any) {
      // 配置鼠标按键对应的事件
      if (_state === STATE.NONE) {
        switch (event.button) {
          case scope.mouseButtons.LEFT:
            _state = STATE.NONE
            break

          case scope.mouseButtons.MIDDLE:
            _state = STATE.PAN
            break

          case scope.mouseButtons.RIGHT:
            _state = STATE.ROTATE
            break

          default:
            _state = STATE.NONE
        }
      }

      const state = _keyState !== STATE.NONE ? _keyState : _state

      if (state === STATE.ROTATE && !scope.noRotate) {
        _moveCurr.copy(getMouseOnCircle(event.pageX, event.pageY))
        _movePrev.copy(_moveCurr)
      } else if (state === STATE.ZOOM && !scope.noZoom) {
        _zoomStart.copy(getMouseOnScreen(event.pageX, event.pageY))
        _zoomEnd.copy(_zoomStart)
      } else if (state === STATE.PAN && !scope.noPan) {
        _panStart.copy(getMouseOnScreen(event.pageX, event.pageY))
        _panEnd.copy(_panStart)
      }

      scope.dispatchEvent(STARTEVENT)
    }
    function onPointerDown(event: any) {
      if (scope.enabled === false) return

      if (_pointers.length === 0) {
        scope.domElement?.setPointerCapture(event.pointerId)

        scope.domElement?.addEventListener('pointermove', onPointerMove)
        scope.domElement?.addEventListener('pointerup', onPointerUp)
      }

      //

      addPointer(event)

      if (event.pointerType === 'touch') {
        onTouchStart(event)
      } else {
        onMouseDown(event)
      }
    }

    function onPointerCancel(event: any) {
      removePointer(event)
    }

    function keydown(event: any) {
      if (scope.enabled === false) return

      window.removeEventListener('keydown', keydown)

      if (_keyState !== STATE.NONE) {
      } else if (event.code === scope.keys[STATE.ROTATE] && !scope.noRotate) {
        _keyState = STATE.ROTATE
      } else if (event.code === scope.keys[STATE.ZOOM] && !scope.noZoom) {
        _keyState = STATE.ZOOM
      } else if (event.code === scope.keys[STATE.PAN] && !scope.noPan) {
        _keyState = STATE.PAN
      }
    }

    function keyup() {
      if (scope.enabled === false) return

      _keyState = STATE.NONE

      window.addEventListener('keydown', keydown)
    }

    function onMouseWheel(event: any) {
      if (scope.enabled === false) return

      if (scope.noZoom === true) return

      event.preventDefault()
      // deltaMode：返回一个数值，表示滚动的单位
      // 0表示像素，1表示行，2表示页。
      switch (event.deltaMode) {
        case 2:
          // Zoom in pages
          _zoomStart.y -= event.deltaY * 0.025
          break

        case 1:
          // Zoom in lines
          _zoomStart.y -= event.deltaY * 0.01
          break

        default:
          // undefined, 0, assume pixels
          _zoomStart.y -= event.deltaY * 0.00025
          break
      }

      scope.dispatchEvent(STARTEVENT)
      scope.dispatchEvent(ENDEVENT)
    }

    function contextmenu(event: any) {
      if (scope.enabled === false) return

      event.preventDefault()
    }

    this.dispose = function () {
      scope.domElement?.removeEventListener('contextmenu', contextmenu)

      scope.domElement?.removeEventListener('pointerdown', onPointerDown)
      scope.domElement?.removeEventListener('pointercancel', onPointerCancel)
      scope.domElement?.removeEventListener('wheel', onMouseWheel)

      scope.domElement?.removeEventListener('pointermove', onPointerMove)
      scope.domElement?.removeEventListener('pointerup', onPointerUp)

      // window.removeEventListener('keydown', keydown)
      // window.removeEventListener('keyup', keyup)
    }

    this.transparentPlane = function (plane) {
      this.addEventListener('change', () => {
        if (this.object) {
          if (this.object.position.z < 0) {
            plane.material.opacity = 0.1
            plane.material.depthWrite = false
          } else {
            plane.material.opacity = 1
            plane.material.depthWrite = true
          }
        }
      })
    }

    this.setXDam = function (val) {
      this.xPanFactor = val
    }

    this.domElement?.addEventListener('contextmenu', contextmenu)

    this.domElement?.addEventListener('pointerdown', onPointerDown)
    this.domElement?.addEventListener('pointercancel', onPointerCancel)
    this.domElement?.addEventListener('wheel', onMouseWheel, { passive: false })

    // window.addEventListener('keydown', keydown)
    // window.addEventListener('keyup', keyup)

    this.handleResize()

    // force an update at start
    this.update()
  }
}

export default TrackballControls

/* eslint-disable no-cond-assign */
/* eslint-disable no-bitwise */
/* eslint-disable class-methods-use-this */
/* eslint-disable @typescript-eslint/no-this-alias */
import {
  BufferAttribute,
  BufferGeometry,
  FileLoader,
  Float32BufferAttribute,
  Loader,
  LoaderUtils,
  Vector3,
} from 'three'

interface Callback {
  successList: BufferGeometry[]
  errorList: Array<File | Blob>
}
interface LoaderOptions {
  noColor?: boolean // 取消颜色属性
  noFaces?: boolean // 取消面片属性
  noFileName?: boolean // 取消文件名属性
  decimals?: number | undefined // 读取模型时保留的最大小数位数
  smoothing?: boolean // 是否平滑模型 // TODO:未实现
}
class STLLoader extends Loader {
  options: LoaderOptions = {
    noColor: true,
    noFaces: false,
    noFileName: false,
    smoothing: false,
  }

  constructor(options?: LoaderOptions) {
    super()
    if (options) {
      Object.assign(this.options, options)
    }
  }

  /**
   * load all files
   * @param targets - array, including files, strings, or blobs
   * @returns Callback - {successList<Array>, errorList<Array>}
   */
  loadAll(targets: Array<string | File | Blob>) {
    return new Promise<Callback>((resolve) => {
      if (!(targets && targets.length)) {
        return
      }
      const successList: BufferGeometry[] = []
      const errorList: Array<File | Blob> = []
      const promiseList: any[] = []
      for (let i = 0; i < targets.length; i++) {
        promiseList.push(this.load(targets[i], true))
      }
      Promise.all(promiseList).then((results: any[]) => {
        for (let m = 0; m < results.length; m++) {
          if (results[m] instanceof BufferGeometry) {
            successList.push(results[m])
          } else {
            errorList.push(results[m])
          }
        }
        resolve({ successList, errorList })
      })
    })
  }

  /**
   * load file or url to bufferGeometry
   * @param target file or url
   * @param handleAll whether to handle all files, default is false
   * @returns a bufferGeometry or error file
   */
  load(target: string | File | Blob, handleAll = false) {
    const scope = this
    return new Promise<BufferGeometry>((resolve, reject) => {
      let fileHandler: FileLoader | FileReader
      let resultGeometry: BufferGeometry
      let fileName: string | null = null
      let isError = false
      const parseFile = () => {
        return new Promise<BufferGeometry>((fileResolve, fileReject) => {
          const handleParse = (targetBuffer: string | ArrayBuffer) => {
            try {
              resultGeometry = scope.parse(targetBuffer)
            } catch (err: any) {
              isError = true
              console.error(err)
            } finally {
              if (isError) {
                fileReject(target)
              } else {
                fileResolve(resultGeometry)
              }
            }
          }
          if (typeof target === 'string') {
            const fileUrl = target.replaceAll('/', '\\')
            fileName = fileUrl.substring(fileUrl.lastIndexOf('\\') + 1)
            fileHandler = new FileLoader()
            fileHandler.setPath(this.path)
            fileHandler.setResponseType('arraybuffer')
            fileHandler.setRequestHeader(this.requestHeader)
            fileHandler.setWithCredentials(this.withCredentials)

            fileHandler.load(target, (text) => {
              handleParse(text)
            })
          } else if (typeof target === 'object') {
            if (target instanceof File || target instanceof Blob) {
              fileName = (target as any).name
              fileHandler = new FileReader()
              fileHandler.readAsArrayBuffer(target)
              fileHandler.onload = (event) => {
                if (event && event.target && event.target.result) {
                  handleParse(event.target.result)
                }
              }
              fileHandler.onerror = (err) => {
                isError = true
                console.error(err)
                fileReject(target)
              }
            }
          }
        })
      }
      parseFile()
        .then((finalGeometry) => {
          if (!this.options.noFileName && fileName) {
            finalGeometry.name = fileName
          }
          resolve(resultGeometry)
        })
        .catch((finalFile) => {
          if (handleAll) {
            resolve(finalFile)
          } else {
            reject(finalFile)
          }
        })
    })
  }

  parse(data: string | ArrayBuffer) {
    const matchDataViewAt = (query: number[], reader: DataView, offset: number): boolean => {
      // Check if each byte in query matches the corresponding byte from the current offset

      for (let i = 0, il = query.length; i < il; i++) {
        if (query[i] !== reader.getUint8(offset + i)) return false
      }

      return true
    }
    const isBinary = (dataInfo: any): boolean => {
      const reader = new DataView(dataInfo)
      const faceSize = (32 / 8) * 3 + (32 / 8) * 3 * 3 + 16 / 8
      const nFaces = reader.getUint32(80, true)
      const expect = 80 + 32 / 8 + nFaces * faceSize

      if (expect === reader.byteLength) {
        return true
      }

      // An ASCII STL data must begin with 'solid ' as the first six bytes.
      // However, ASCII STLs lacking the SPACE after the 'd' are known to be
      // plentiful.  So, check the first 5 bytes for 'solid'.

      // Several encodings, such as UTF-8, precede the text with up to 5 bytes:
      // https://en.wikipedia.org/wiki/Byte_order_mark#Byte_order_marks_by_encoding
      // Search for "solid" to start anywhere after those prefixes.

      // US-ASCII ordinal values for 's', 'o', 'l', 'i', 'd'

      const solid = [115, 111, 108, 105, 100]

      for (let off = 0; off < 5; off++) {
        // If "solid" text is matched to the current offset, declare it to be an ASCII STL.

        if (matchDataViewAt(solid, reader, off)) return false
      }

      // Couldn't find "solid" text at the beginning; it is binary STL.

      return true
    }

    const parseBinary = (fileData: any): BufferGeometry => {
      const reader = new DataView(fileData)
      const faces = reader.getUint32(80, true)

      let r!: number
      let g!: number
      let b!: number
      let hasColors = false
      let colors!: Float32Array
      let defaultR!: number
      let defaultG!: number
      let defaultB!: number
      let alpha
      let facesProperty: any[] | null = null
      interface FaceVertices {
        a: number[] | null
        b: number[] | null
        c: number[] | null
      }
      const decimals: number | null = this.options.decimals === undefined ? null : 10 ** this.options.decimals
      // process STL header
      // check for default color in header ("COLOR=rgba" sequence).
      // noColor不进行有无颜色检测
      if (!this.options.noColor) {
        for (let index = 0; index < 80 - 10; index++) {
          if (
            reader.getUint32(index, false) === 0x434f4c4f /* COLO */ &&
            reader.getUint8(index + 4) === 0x52 /* 'R' */ &&
            reader.getUint8(index + 5) === 0x3d /* '=' */
          ) {
            hasColors = true
            colors = new Float32Array(faces * 3 * 3)

            defaultR = reader.getUint8(index + 6) / 255
            defaultG = reader.getUint8(index + 7) / 255
            defaultB = reader.getUint8(index + 8) / 255
            alpha = reader.getUint8(index + 9) / 255
          }
        }
      }

      const dataOffset = 84
      const faceLength = 12 * 4 + 2

      const geometry = new BufferGeometry()

      const vertices = new Float32Array(faces * 3 * 3)
      const normals = new Float32Array(faces * 3 * 3)
      if (!this.options.noFaces) {
        facesProperty = []
        facesProperty.length = faces
      }
      for (let face = 0; face < faces; face++) {
        const start = dataOffset + face * faceLength
        const normalX = reader.getFloat32(start, true)
        const normalY = reader.getFloat32(start + 4, true)
        const normalZ = reader.getFloat32(start + 8, true)
        if (facesProperty) {
          let faceNormals!: number[]
          if (this.options.decimals === undefined) {
            faceNormals = [normalX, normalY, normalZ]
          } else if (typeof this.options.decimals === 'number' && decimals) {
            faceNormals = [
              Math.round(normalX * decimals) / decimals,
              Math.round(normalY * decimals) / decimals,
              Math.round(normalZ * decimals) / decimals,
            ]
          }
          facesProperty[face] = {
            vertices: <FaceVertices>{ a: null, b: null, c: null },
            normal: <number[]>faceNormals,
            faceIndex: <number>face,
            positions: <number[]>[face * 9, face * 9 + 8],
          }
        }
        if (hasColors) {
          const packedColor = reader.getUint16(start + 48, true)

          if ((packedColor & 0x8000) === 0) {
            // facet has its own unique color

            r = (packedColor & 0x1f) / 31
            g = ((packedColor >> 5) & 0x1f) / 31
            b = ((packedColor >> 10) & 0x1f) / 31
          } else {
            r = defaultR
            g = defaultG
            b = defaultB
          }
        }

        for (let i = 1; i <= 3; i++) {
          const vertexstart = start + i * 12
          const componentIdx = face * 3 * 3 + (i - 1) * 3

          vertices[componentIdx] = reader.getFloat32(vertexstart, true)
          vertices[componentIdx + 1] = reader.getFloat32(vertexstart + 4, true)
          vertices[componentIdx + 2] = reader.getFloat32(vertexstart + 8, true)

          normals[componentIdx] = normalX
          normals[componentIdx + 1] = normalY
          normals[componentIdx + 2] = normalZ

          if (hasColors) {
            colors[componentIdx] = r
            colors[componentIdx + 1] = g
            colors[componentIdx + 2] = b
          }
          if (facesProperty) {
            let faceVerticess!: number[]
            if (this.options.decimals === undefined) {
              faceVerticess = [vertices[componentIdx], vertices[componentIdx + 1], vertices[componentIdx + 2]]
            } else if (typeof this.options.decimals === 'number' && decimals) {
              faceVerticess = [
                Math.round(vertices[componentIdx] * decimals) / decimals,
                Math.round(vertices[componentIdx + 1] * decimals) / decimals,
                Math.round(vertices[componentIdx + 2] * decimals) / decimals,
              ]
            }
            if (faceVerticess) facesProperty[face].vertices[String.fromCharCode(i + 96)] = faceVerticess
          }
        }
      }

      geometry.setAttribute('position', new BufferAttribute(vertices, 3))
      geometry.setAttribute('normal', new BufferAttribute(normals, 3))

      if (hasColors) {
        geometry.setAttribute('color', new BufferAttribute(colors, 3))
        ;(geometry as any).hasColors = true
        ;(geometry as any).alpha = alpha
      }
      if (facesProperty) {
        ;(geometry as any).facess = facesProperty
      }

      return geometry
    }

    // TODO: 增加（noFaces、smoothing等）参数相关属性处理方法
    const parseASCII = (fileData: any): BufferGeometry => {
      const geometry = new BufferGeometry()
      const patternSolid = /solid([\s\S]*?)endsolid/g
      const patternFace = /facet([\s\S]*?)endfacet/g
      let faceCounter = 0

      const patternFloat = /[\s]+([+-]?(?:\d*)(?:\.\d*)?(?:[eE][+-]?\d+)?)/.source
      const patternVertex = new RegExp(`vertex${patternFloat}${patternFloat}${patternFloat}`, 'g')
      const patternNormal = new RegExp(`normal${patternFloat}${patternFloat}${patternFloat}`, 'g')

      const vertices = []
      const normals = []

      const normal = new Vector3()

      let groupCount = 0
      let startVertex = 0
      let endVertex = 0
      let result
      while ((result = patternSolid.exec(fileData)) !== null) {
        startVertex = endVertex

        const solid = result[0]

        while ((result = patternFace.exec(solid)) !== null) {
          let vertexCountPerFace = 0
          let normalCountPerFace = 0

          const text = result[0]

          while ((result = patternNormal.exec(text)) !== null) {
            normal.x = parseFloat(result[1])
            normal.y = parseFloat(result[2])
            normal.z = parseFloat(result[3])
            normalCountPerFace += 1
          }

          while ((result = patternVertex.exec(text)) !== null) {
            vertices.push(parseFloat(result[1]), parseFloat(result[2]), parseFloat(result[3]))
            normals.push(normal.x, normal.y, normal.z)
            vertexCountPerFace += 1
            endVertex += 1
          }

          // every face have to own ONE valid normal

          if (normalCountPerFace !== 1) {
            console.error(`THREE.STLLoader: Something isn't right with the normal of face number ${faceCounter}`)
          }

          // each face have to own THREE valid vertices

          if (vertexCountPerFace !== 3) {
            console.error(`THREE.STLLoader: Something isn't right with the vertices of face number ${faceCounter}`)
          }
          faceCounter += 1
        }

        const start = startVertex
        const count = endVertex - startVertex

        geometry.addGroup(start, count, groupCount)
        groupCount += 1
      }

      geometry.setAttribute('position', new Float32BufferAttribute(vertices, 3))
      geometry.setAttribute('normal', new Float32BufferAttribute(normals, 3))

      return geometry
    }

    const ensureString = (buffer: any) => {
      if (typeof buffer !== 'string') {
        return LoaderUtils.decodeText(new Uint8Array(buffer))
      }

      return buffer
    }

    const ensureBinary = (buffer: any) => {
      if (typeof buffer === 'string') {
        const arrayBuffer = new Uint8Array(buffer.length)
        for (let i = 0; i < buffer.length; i++) {
          arrayBuffer[i] = buffer.charCodeAt(i) & 0xff // implicitly assumes little-endian
        }

        return arrayBuffer.buffer || arrayBuffer
      }
      return buffer
    }

    // start parse
    const binData = ensureBinary(data)
    const resultGeometry: BufferGeometry = isBinary(binData) ? parseBinary(binData) : parseASCII(ensureString(data))

    // TODO: 未完成的功能, 调用mergevertices平滑模型
    // if (this.options.smoothing) {
    //   const resetAllAttributes = (): void => {
    //     resultGeometry?.deleteAttribute('normal')
    //   }
    // }

    const isNormal = this.checkGeometry(resultGeometry)
    if (!isNormal) {
      resultGeometry.dispose()
      throw new Error('Computed radius is NaN. The "position" attribute is likely to have NaN values')
    }
    return resultGeometry
  }

  checkGeometry = (geometry: BufferGeometry): boolean => {
    geometry.computeBoundingSphere()
    return !Number.isNaN(geometry?.boundingSphere?.radius)
  }
}

export default STLLoader

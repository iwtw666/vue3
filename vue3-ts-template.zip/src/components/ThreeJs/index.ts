// 定义所有threejs相关的组件
import { STLExporter } from 'three/examples/jsm/exporters/STLExporter'
import { TransformControls } from 'three/examples/jsm/controls/TransformControls.js'
import { DragControls } from 'three/examples/jsm/controls/DragControls.js'
import {
  computeMikkTSpaceTangents,
  mergeBufferGeometries,
  mergeBufferAttributes,
  interleaveAttributes,
  estimateBytesUsed,
  mergeVertices,
  toTrianglesDrawMode,
  computeMorphedAttributes,
  mergeGroups,
} from 'three/examples/jsm/utils/BufferGeometryUtils.js'
import { ThreeJs, THREE } from './modules/ThreeJs'
import STLLoader from './modules/STLLoader'
import TrackballControls from './modules/TrackballControls'

const BufferGeometryUtils: object = {
  computeMikkTSpaceTangents,
  mergeBufferGeometries,
  mergeBufferAttributes,
  interleaveAttributes,
  estimateBytesUsed,
  mergeVertices,
  toTrianglesDrawMode,
  computeMorphedAttributes,
  mergeGroups,
}

export {
  ThreeJs,
  THREE,
  STLLoader,
  STLExporter,
  DragControls,
  TransformControls,
  TrackballControls,
  BufferGeometryUtils,
}

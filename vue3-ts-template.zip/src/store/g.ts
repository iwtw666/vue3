import { defineStore } from 'pinia'

const g = defineStore({
  // 这里的id必须为唯一ID
  id: 'global',
  state: () => {
    return {
      models: <any>[],
    }
  },
  // 等同于vuex的getter
  getters: {
    getModels: (state) => state.models,
  },
  // pinia 放弃了 mutations 只使用 actions
  actions: {
    // actions可以用async做成异步形式
    addModels(item: any) {
      this.models.push(item)
    },
  },
})

export default g

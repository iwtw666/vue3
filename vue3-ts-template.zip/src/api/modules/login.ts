import ajax from '@/api/http'

const loginApi = {
  // 验证登录实例
  postVerification: (params: object) => ajax.post(`/login`, params),
}

export default loginApi
